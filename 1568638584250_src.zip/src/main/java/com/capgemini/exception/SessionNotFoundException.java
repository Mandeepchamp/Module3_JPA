package com.capgemini.exception;

public class SessionNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public SessionNotFoundException(String msg) {
		super(msg);
	}

}
