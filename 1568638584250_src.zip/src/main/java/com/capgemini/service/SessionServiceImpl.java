package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.SessionDao;
import com.capgemini.model.Session;

@Service
public class SessionServiceImpl implements SessionService {

	@Autowired
	private SessionDao dao;

	public void addSession(Session session) {
		dao.beginTransaction();
		dao.addSession(session);
		dao.commitTransaction();
	}

	public void modifySession(Session session) {
		dao.beginTransaction();
		dao.updateSession(session);
		dao.commitTransaction();
	}

	public void removeSession(Session session) {
		dao.beginTransaction();
		dao.deleteSession(session);
		dao.commitTransaction();
	}

	public List<Session> findAllSession() {
		return dao.ViewAllSession();
	}

	public Session findSessionById(int id) {
		Session session = dao.getSessionById(id);
		return session;

	}

	public boolean durationValidation(int duration) {
		if (duration < 3) {
			return false;
		}
		return true;
	}

	public boolean modeValidation(String mode) {
		if (mode.equals("ILT") || mode.equals("VC")) {
			return true;
		}
		return false;
	}

}
