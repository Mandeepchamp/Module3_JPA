package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.model.Session;

@Repository
public class SessionDaoImpl implements SessionDao {

	private EntityManager entityManager;

	public SessionDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	public void addSession(Session session) {
		if (session != null) {
			entityManager.persist(session);
		}
	}

	public void updateSession(Session session) {
		entityManager.merge(session);
	}

	public void deleteSession(Session session) {
		session = entityManager.find(Session.class, session.getId());
		entityManager.remove(session);

	}

	public List<Session> ViewAllSession() {

		String query = "From SessionTable";
		TypedQuery<Session> tquery = entityManager.createQuery(query, Session.class);
		List<Session> list = tquery.getResultList();
		return list;
	}

	public void commitTransaction() {
		entityManager.getTransaction().commit();

	}

	public void beginTransaction() {
		entityManager.getTransaction().begin();

	}

	public Session getSessionById(int id) {
		Session session = entityManager.find(Session.class, id);
		return session;
	}

}
