package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Session;

public interface SessionService {

	public abstract void addSession(Session session);

	public abstract void modifySession(Session session);

	public abstract void removeSession(Session session);

	public abstract List<Session> findAllSession();

	public abstract Session findSessionById(int id);

	public abstract boolean durationValidation(int duration);

	public abstract boolean modeValidation(String mode);

}
